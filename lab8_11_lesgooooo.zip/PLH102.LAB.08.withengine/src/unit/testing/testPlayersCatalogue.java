package unit.testing;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import engine.TttEngine;
import model.PlayersCatalogue;

public class testPlayersCatalogue {
	
	TttEngine engine = null;
	PlayersCatalogue catalogue = new PlayersCatalogue(engine);
	
	@Test
	public void testGetPlayerObj_fromName() {
		assertNotNull(catalogue.getPlayerObj_fromName("Yannis"));
		
		assertNull(catalogue.getPlayerObj_fromName("awda4gfrtg_(&$#eriuh"));
	}
	
}
