package unit.testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

import control.GameStates;

public class TestGameStates {
	
	GameStates s = new GameStates();
	
	@Test
	public void testGameStates() {
		//testing the 'normal' flow  ||  0 -> 1 -> 2 -> 3 -> 4 -> 0
		
		/* state 0 : initial state
		 * state 1 : select player 1
		 * state 2 : select player 2
		 * state 3 : start game
		 * state 4 : game ends
		 */
		
		
		GameStates.resetState();
		assertEquals(GameStates.state,GameStates.STATE_INITIAL);
		
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_1);
		assertEquals(GameStates.state,GameStates.STATE_SELECT_PLAYER_1);
		
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_2);
		assertEquals(GameStates.state,GameStates.STATE_SELECT_PLAYER_2);
		
		GameStates.changeState(GameStates.EVENT_START_GAME);
		assertEquals(GameStates.state,GameStates.STATE_GAME_START);
		
		GameStates.changeState(GameStates.EVENT_END_GAME);
		assertEquals(GameStates.state,GameStates.STATE_GAME_FINISH);		

		GameStates.changeState(GameStates.EVENT_RESET_GAME);
		assertEquals(GameStates.state,GameStates.STATE_INITIAL);
		
		//tetsing the 'different' flows
		
		//2 -> 1
		GameStates.state = GameStates.STATE_SELECT_PLAYER_2;
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_1);
		assertEquals(GameStates.state,GameStates.STATE_SELECT_PLAYER_1);
		
		//0 -> 2
		GameStates.state = GameStates.STATE_INITIAL;
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_2);
		assertEquals(GameStates.state,GameStates.STATE_SELECT_PLAYER_2);
		
		//1 -> 3
		GameStates.state = GameStates.STATE_SELECT_PLAYER_1;
		GameStates.changeState(GameStates.EVENT_START_GAME);
		assertEquals(GameStates.state,GameStates.STATE_GAME_START);
		
		//testing if state 3 can be initiated with only one of two players selected
		
		//selecting only player 1
		GameStates.resetState();
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_1);
		GameStates.changeState(GameStates.EVENT_START_GAME);
		assertFalse(GameStates.state == GameStates.STATE_GAME_START);
		assertEquals(GameStates.ERROR_STATE,GameStates.state);
		
		//selecting only player 2
		GameStates.resetState();
		GameStates.changeState(GameStates.EVENT_SEL_PLAYER_2);
		GameStates.changeState(GameStates.EVENT_START_GAME);
		assertFalse(GameStates.state == GameStates.STATE_GAME_START);
		assertEquals(GameStates.ERROR_STATE,GameStates.state);

		
	}
	
	
}
