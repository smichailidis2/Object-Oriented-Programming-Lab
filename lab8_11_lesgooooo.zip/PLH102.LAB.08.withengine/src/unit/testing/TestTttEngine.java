package unit.testing;
import engine.*;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import engine.TttEngine.Board;

public class TestTttEngine {
	
	//@Test
	public void testGetRandomValue() {
		for (int i = 0; i < 1000000; i++) {
			//System.out.println(TttEngine.getRandomValue());
			assertTrue(TttEngine.getRandomValue() < 4 && TttEngine.getRandomValue() > -1);
		}
	}
	
	@Test
	public void testbestB() {
		TttEngine testEngine = new TttEngine();
		
		Board b = testEngine.new Board();		//For this to work , set inner class Board of class engine.TttEngine to public !
		
		//0 value ... empty cell
		//1 value ... X cell
		//2 value ... O cell
		
		//for boolean: FALSE -> X  &  TRUE -> O
		//player  O  always starts first
		
		//tie for both players
		
		b.setBoard(2, 1, 2,
				   1, 2, 1,
				   1, 2, 1,
				   0);
		System.out.println("TEST 1 ------------------");
		assertEquals(0, testEngine.bestB(false, b));
		System.out.println("TEST 2 ------------------");
		assertEquals(0, testEngine.bestB(true, b));
		
		//ttt by O
		b.setBoard(2, 1, 0,
				   1, 1, 0,
				   2, 2, 2,
				   2);
		System.out.println("TEST 3 ------------------");
		assertEquals(1,testEngine.bestB(true, b)); //win for O
		System.out.println("TEST 4 ------------------");
		assertEquals(-1,testEngine.bestB(false, b)); //loss for X
		
		//ttt by X
		b.setBoard(2, 0, 1,
				   2, 1, 1,
				   1, 2, 2,
				   1);
		System.out.println("TEST 5 ------------------");
		assertEquals(1,testEngine.bestB(false, b)); //win for X
		System.out.println("TEST 6 ------------------");
		assertEquals(-1,testEngine.bestB(true, b)); //loss for O
		
		//tie , one move remaining
		b.setBoard(2, 2, 1,
				   1, 1, 0,
				   2, 1, 2,
				   1);
		System.out.println("TEST 7 ------------------");
		assertEquals(0,testEngine.bestB(true, b)); 
		System.out.println("TEST 8 ------------------");
		assertEquals(1,testEngine.bestB(false, b)); 
		
		
		//decisive victory by X , one move remaining
		b.setBoard(2, 0, 2,
				   0, 1, 1,
				   1, 2, 2,
				   2);
		System.out.println("TEST 9 ------------------");
		assertEquals(1,testEngine.bestB(false, b)); //win for X
		
		b.setBoard(1, 0, 1,
				   0, 2, 2,
				   2, 1, 1,
				   2);
		System.out.println("TEST 9.1 ----------------");
		assertEquals(1,testEngine.bestB(true, b)); //win for O
		
		
		//decisive victory by O , two moves remaining
		b.setBoard(2, 2, 1,
				   1, 2, 0,
				   0, 0, 0,
				   4);
		System.out.println("TEST 10 -----------------");
		assertEquals(1,testEngine.bestB(true, b)); //win for O
		
		//decisive win for O , X to play
		b.setBoard(2, 1, 0,
				   0, 2, 0,
				   0, 0, 0,
				   6);
		System.out.println("TEST 11 -----------------");
		assertEquals(-1,testEngine.bestB(false, b)); //loosing position for X
		
		// future draw for both players , X to play
		b.setBoard(2, 0, 0,
				   0, 0, 0,
				   0, 0, 0,
				   8);
		System.out.println("TEST 12 -----------------");
		assertEquals(0,testEngine.bestB(false, b)); //draw position for X
		
		// future win for O , O to play
		b.setBoard(2, 1, 0,
				   0, 0, 0,
				   0, 0, 0,
				   7);
		System.out.println("TEST 12.1 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 1,
				   0, 0, 0,
				   0, 0, 0,
				   7);
		System.out.println("TEST 12.2 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 0,
				   0, 0, 1,
				   0, 0, 0,
				   7);
		System.out.println("TEST 12.3 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 0,
				   0, 0, 0,
				   0, 0, 1,
				   7);
		System.out.println("TEST 12.4 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 0,
				   0, 0, 0,
				   0, 1, 0,
				   7);
		System.out.println("TEST 12.5 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 0,
				   0, 0, 0,
				   1, 0, 0,
				   7);
		System.out.println("TEST 12.6 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future win for O , O to play
		b.setBoard(2, 0, 0,
				   1, 0, 0,
				   0, 0, 0,
				   7);
		System.out.println("TEST 12.7 ---------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future draw , O to play
		b.setBoard(2, 0, 0,
				   0, 1, 0,
				   0, 0, 0,
				   7);
		System.out.println("TEST 12.7 ---------------");
		assertEquals(0,testEngine.bestB(true, b));
		
		
		// future draw , X to play
		b.setBoard(0, 2, 0,
				   2, 1, 1,
				   2, 1, 2,
				   2);
		System.out.println("TEST 13 -----------------");
		assertEquals(0,testEngine.bestB(false, b)); 
		
		
		// future draw , O to play
		b.setBoard(0, 2, 1,
				   2, 1, 1,
				   2, 1, 2,
				   1);
		System.out.println("TEST 14 -----------------");
		assertEquals(1,testEngine.bestB(true, b)); 
		
		// future draw , O to play
		b.setBoard(1, 2, 0,
				   2, 1, 1,
				   2, 1, 2,
				   1);
		System.out.println("TEST 14 -----------------");
		assertEquals(0,testEngine.bestB(true, b)); 
		
		
		
		System.out.println("\n");
				
		
		
		
	}
	
	@Test
	public void testGetBestmove() {
		
		TttEngine testEngine = new TttEngine();
		
		Board b = testEngine.new Board();		//For this to work , set inner class Board of class engine.TttEngine to public !
		testEngine.setBoard(b);
		
		//0 value ... empty cell
		//1 value ... X cell
		//2 value ... O cell
		
		//for boolean: FALSE -> X  &  TRUE -> O
		//player  O  always starts first
		
		System.out.println("Test --1-- for bestMove");		
		b.setBoard(2, 2, 0,
				   1, 1, 1,
				   2, 0, 0,
				   3);
		testEngine.setPlayerToMove(true);
		
		Coordinates c = testEngine.getBestmove();
		
		assertNull(c);
		
		System.out.println("Test --2-- for bestMove");
		b.setBoard(2, 2, 1,
				   1, 1, 0,
				   2, 1, 2,
				   1);
		testEngine.setPlayerToMove(true);
		
		Coordinates c1 = testEngine.getBestmove();
		
		//assertNull(c1);
		assertTrue(c1.getX() == 1 && c1.getY() == 2);
		
		
		System.out.println("Test --3-- for bestMove");
		b.setBoard(2, 2, 0,
				   1, 1, 0,
				   0, 0, 0,
				   5);
		testEngine.setPlayerToMove(true);
		
		Coordinates c2 = testEngine.getBestmove();
		
		//assertNull(c2);
		assertTrue(c2.getX() == 0 && c2.getY() == 2);
		
		System.out.println("Test --4-- for bestMove");
		b.setBoard(2, 2, 0,
				   1, 1, 0,
				   2, 0, 0,
				   4);
		testEngine.setPlayerToMove(false);
		
		Coordinates c3 = testEngine.getBestmove();
		
		//assertNull(c3);
		assertTrue(c3.getX() == 1 && c3.getY() == 2);
		
		System.out.println("Test --5-- for bestMove");
		b.setBoard(2, 2, 0,
				   1, 0, 0,
				   2, 0, 1,
				   4);
		testEngine.setPlayerToMove(false);
		
		Coordinates c4 = testEngine.getBestmove();
		
		//assertNull(c4);
		assertTrue(c4.getX() == 0 && c4.getY() == 2);
		
		System.out.println("Test --6-- for bestMove");
		b.setBoard(2, 0, 0,
				   0, 1, 0,
				   0, 0, 0,
				   7);
		testEngine.setPlayerToMove(true);
		
		Coordinates c5 = testEngine.getBestmove();
		
		assertNotNull(c5); //enabling the debug print loop in getBestMove shows all potential best moves!
		
		System.out.println("Test --7-- for bestMove");
		b.setBoard(2, 0, 0,
				   1, 0, 0,
				   0, 0, 0,
				   7);
		testEngine.setPlayerToMove(true);
		
		Coordinates c6 = testEngine.getBestmove();
		
		assertNotNull(c6); //enabling the debug print loop in getBestMove shows all potential best moves!
		
		System.out.println("Test --8-- for bestMove");
		b.setBoard(2, 0, 0,
				   0, 0, 0,
				   0, 0, 0,
				   8);
		testEngine.setPlayerToMove(false);
		
		Coordinates c7 = testEngine.getBestmove();
		
		assertNotNull(c7); //enabling the debug print loop in getBestMove shows all potential best moves!

		
		
		System.out.println("Test --9-- for bestMove");
		b.setBoard(0, 0, 0,
				   0, 0, 0,
				   0, 0, 0,
				   9);
		testEngine.setPlayerToMove(true);
		
		Coordinates c8 = testEngine.getBestmove();
		
		assertNotNull(c8); //enabling the debug print loop in getBestMove shows all potential best moves!

		
		
		System.out.println("Test --10-- for bestMove");
		b.setBoard(0, 2, 0,
				   2, 1, 1,
				   2, 1, 2,
				   2);
		testEngine.setPlayerToMove(false);
		
		Coordinates c9 = testEngine.getBestmove();
		
		assertNotNull(c9); //enabling the debug print loop in getBestMove shows all potential best moves!
		
		
		
		System.out.println("Test --11-- for bestMove");
		b.setBoard(0, 1, 2,
				   1, 2, 0,
				   0, 0, 0,
				   5);
		testEngine.setPlayerToMove(true);
		
		Coordinates c10 = testEngine.getBestmove();
		
		assertNotNull(c10); //enabling the debug print loop in getBestMove shows all potential best moves!
		
		
		System.out.println("\n");
		
	}
	
	@Test
	public void testGetMrBEANmove() {
		
		TttEngine testEngine = new TttEngine();
		
		Board b = testEngine.new Board();		//For this to work , set inner class Board of class engine.TttEngine to public !
		testEngine.setBoard(b);
		
		//0 value ... empty cell
		//1 value ... X cell
		//2 value ... O cell
		
		//for boolean: FALSE -> X  &  TRUE -> O
		//player  O  always starts first
		
		System.out.println("Test == 1 == for random move");
		assertNotNull(testEngine.getMrBEANmove());
	}
	
}
