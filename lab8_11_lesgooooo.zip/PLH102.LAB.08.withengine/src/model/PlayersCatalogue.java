package model;

import java.util.ArrayList;
import java.util.Iterator;

import engine.TttEngineInterface;

public class PlayersCatalogue {
	private Player[] players;
	private ArrayList<Player> playerList = new ArrayList<Player>();
	
	TttEngineInterface engine;
	
	public static int PLAYER_COUNT = 7;
	
	
	public PlayersCatalogue(TttEngineInterface engine) {
		
		this.engine = engine;
		
		players = new Player[PLAYER_COUNT];
		
		players[0] = new AI("AI_Hal_1");
		players[1] = new AI("AI_Hal_2");
		players[2] = new AI("AI_MrBean");
		players[3] = new Person("Vasilis");
		players[4] = new Person("Nektarios");
		players[5] = new Person("Yannis");
		players[6] = new Person("Eleni");
		
		playerList.add(new     AI("AI_Hal_1",engine));
		playerList.add(new     AI("AI_Hal_2",engine));
		playerList.add(new     AI("AI_MrBean",engine));
		playerList.add(new Person("Vasilis"));
		playerList.add(new Person("Nektarios"));
		playerList.add(new Person("Yannis"));
		playerList.add(new Person("Eleni"));
	}
	
	
	
	public String getPlayer(int i) {
		if (i<0 || i>4) {
			return null;
		}
		return players[i].name;
	}
	
	public Player getPlayerFromList(int i) {
		return playerList.get(i);
	}
	
	
	public String[] getPlayers() {
		String[] retString = new String[PLAYER_COUNT];
		
		for (int i = 0; i < PLAYER_COUNT; i++) {
			retString[i] = players[i].name;
		}
		
		return retString;
	}
	
	
	public String[] getPlayersFromList() {
		String[] retString = new String[playerList.size()];
		
		for (int i = 0; i < playerList.size(); i++) {
			retString[i] = playerList.get(i).name;
		}
		
		return retString;
	}
	
	public void addPlayerToCatalog(String name) {
		
		if (isInCatalogue(name)) {
			System.out.println("THERE ALREADY EXISTS A PLAYER :" + name);
			return;
		}
		
		Person newPlayer = new Person(name);
		
		playerList.add(newPlayer);
	}
	
	private boolean isInCatalogue(String name) {
		
		Iterator<Player> iterator = playerList.iterator();
		
		while (iterator.hasNext()) {
			if (iterator.next().name.equals(name)) {
				return true;
			}
		}
		
		return false;
		
	}
	
	public Player getPlayerObj_fromName(String name) {
		
		Iterator<Player> iterator = playerList.iterator();
		
		
		while (iterator.hasNext()) {
			Player next = iterator.next();
			if (next.name.equals(name)) {
				//System.out.println("getPlayerObj_fromName : object found;");
				return next;
			}
		}
		
		return null;
	}
	
}
