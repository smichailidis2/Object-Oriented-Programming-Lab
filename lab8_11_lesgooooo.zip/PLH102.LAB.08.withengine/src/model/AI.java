package model;

import engine.Coordinates;
import engine.TttEngineInterface;

public class AI extends Player{
	
	TttEngineInterface engine = null;

	public AI(String name, GameHistory h) {
		super(name, h);
	}
	
	public AI(String name) {
		super(name, null);
	}
	
	public AI(String name, TttEngineInterface engine) {
		super(name, null);
		this.engine = engine;
	}


	@Override
	public void getGameHistory() {
		
	}
	
	
	private Coordinates getRandomMove() { // for MrBean_AI
		if (this.engine == null)
			return null;
		else
			return this.engine.getMrBEANmove(); 		
	}
	
	private Coordinates getBestMove() {	// for Hal_AI
		if (this.engine == null)
			return null;
		else
			return this.engine.getBestmove(); 
		
	}
	
	//DEPENDS ON THE NAME OF THE BOT, 
	//decides wether the method getBestMove or getRandomMove is applied.
	public Coordinates makeAImove() {
		if(this.name.equals("AI_MrBean")) {
			return this.getRandomMove();
		} else {
			return this.getBestMove();
		}
	}
	
	//overriding toSting
	@Override
	public String toString() {
		return this.name;
	}
}
