package model;

public class Person extends Player{

	public Person(String name, GameHistory h) {
		super(name, h);
	}
	
	public Person(String name) {
		super(name,null);
	}

	@Override
	public void getGameHistory() {
		
	}
	
	//overriding toSting
	@Override
	public String toString() {
		return this.name;
	}

}
