package engine;

import java.util.Arrays;
import java.util.Random;

public final class TttEngine implements TttEngineInterface{
	
	
	private boolean playerToMove = true;	//( X ) -> false || ( O ) player -> true
	
	public int rec_depth = 0; //recursive depth level , used in unit testing for method TttEngine.bestB
	
	public static int BESTB_ERRORCODE = -999;
	
	private Board board = null;
	
	public TttEngine() {
		
	}
	

	@Override
	public void switchPlayer() {
		playerToMove = !playerToMove;
	}

	@Override
	public boolean playerToMove() {
		return true;
	}

	@Override
	public void makeMove(Coordinates c) throws TttExceptions{
		
		if(playerToMove) {
			board.setCellValue(c, 2); //put O 
		} else {
			board.setCellValue(c, 1); //put X
		}
		
		//check if win condition reached for the current player - 'playerToMove'		
		if(this.hasPlayerWon(playerToMove)) {
			throw new TttExceptions(TttExceptions.WINNING_POSITION,TttExceptions.WINNING_POSITION_DESCRIPTION,playerToMove);
		}
		if (board.number_of_free_cells == 0) {				
			throw new TttExceptions(TttExceptions.DRAW_POSITION,TttExceptions.DRAW_POSIITON_DESCRIPTION);
		}
		

		this.switchPlayer();
	}

	@Override
	public Coordinates getMrBEANmove() {
		//checks if game is over
		if (this.isFinalBoard()) {
			return null;
		}
		
		Coordinates[] availableMoves = this.board.findFreeCells(this.board);
		
		//DEBUG LOOP FOR UNIT TESTING , SHOWS ALL POTENTIAL BEST MOVES!!! TODO UNIT TESTING mrBeanMove
		/*for (int q =0; q<this.board.number_of_free_cells; q++) {
			System.out.println("	potential random move " + (q+1) + " :");
			System.out.println("	" + availableMoves[q].x + " " + availableMoves[q].y);
		}*/
		
		return availableMoves[generatedRandom(this.board.number_of_free_cells)];
	}

	@Override
	public Coordinates getBestmove() {
		
		//checks if game is over
		if (this.isFinalBoard()) {
			return null;
		}
		
		Coordinates[] bestMoves = new Coordinates[9]; 
		int idx = 0;
		Coordinates[] availableMoves = this.board.findFreeCells(this.board);
		
		int bestb_current = bestB(playerToMove, board);
		int bestb_next = -100;
		
		//System.out.println(" first Coordinate c = " + availableMoves[0].x + " " + availableMoves[0].y); //DEBUG PRINTS FOR TEST UNIT
		//System.out.println("BestB=" + bestb_current + "player=" + playerToMove);		
		
		for (Coordinates c : availableMoves) {
		
			
			//System.out.println("entered for loop");					//DEBUG PRINTS FOR TEST UNIT
			//System.out.println("bestb current = " + bestb_current);	//DEBUG PRINTS FOR TEST UNIT
			
			if (c == null) {
				//System.out.println("getBestMove : idx = " + idx + " NULL COORDINATES");	//DEBUG PRINTS FOR TEST UNIT	
				break;
			}
			//System.out.println("x=" + c.getX() + "    y=" + c.getY());
			
			
			Board potential_next_board = new Board(this.board);
			
			potential_next_board.setCellValue(c, (playerToMove)?2 : 1);
			
			bestb_next = -1 * bestB(!playerToMove, potential_next_board);
			//System.out.println("BestB'=" + -1*bestb_next + "player=" + !playerToMove);
			
			if (bestb_next == bestb_current) {
				bestMoves[idx++] = c;
			}
		}
		
		if (idx == 0) {
			//System.out.println("getBestMove : NO FREE CELL FOUND");	//DEBUG PRINTS FOR TEST UNIT
			
			return null; //no move available
		}
		else {
			
			//DEBUG LOOP FOR UNIT TESTING , SHOWS ALL POTENTIAL BEST MOVES!!! TODO UNIT TESTING hal
			for (int q =0; q<idx; q++) {
				System.out.println("	potential best move " + (q+1) + " :");
				System.out.println("	" + bestMoves[q].x + " " + bestMoves[q].y);
			}
			
			return bestMoves[generatedRandom(idx)];
		}
			
	}

	
	/*
	 * Ipmlements min - max algorithm...
	 * 
	 * 
	 */
	@Override
	public int bestBoard(boolean player_to_move, int[][] board) {
		
		if (hasPlayerWon(player_to_move) || isFinalBoard()) {
			
		}
		
		
		return 0;
	}

	@Override
	public boolean isFinalBoard() {
		return this.board.isBoardFinal(board) == 0
			|| this.board.isBoardFinal(board) == 1
			|| this.board.isBoardFinal(board) == 2;
	}
	
	public static int getRandomValue() {
		return new Random().nextInt(Board.tttDimension + 1);	//generates random integer from 0 to 3
	}
	
	public static int generatedRandom(int x) {
		return new Random().nextInt(x);		//generates random integer from in the field [o , x)
	}

	
	//returns true if player reached winning position
	//player=FALSE (X player),  player=TRUE (O player),
	private boolean hasPlayerWon(boolean player) {
		
		int cell_val = (player) ? 2 : 1;
		
			return 
				   (board.getCellValue(new Coordinates(0,0) ) == cell_val && board.getCellValue(new Coordinates(0,1) ) == cell_val  && board.getCellValue(new Coordinates(0,2) ) == cell_val) 
			   ||  (board.getCellValue(new Coordinates(1,0) ) == cell_val && board.getCellValue(new Coordinates(1,1) ) == cell_val  && board.getCellValue(new Coordinates(1,2) ) == cell_val) 
			   ||  (board.getCellValue(new Coordinates(2,0) ) == cell_val && board.getCellValue(new Coordinates(2,1) ) == cell_val  && board.getCellValue(new Coordinates(2,2) ) == cell_val) 
			   ||  (board.getCellValue(new Coordinates(0,0) ) == cell_val && board.getCellValue(new Coordinates(1,0) ) == cell_val  && board.getCellValue(new Coordinates(2,0) ) == cell_val) 
    		   ||  (board.getCellValue(new Coordinates(0,1) ) == cell_val && board.getCellValue(new Coordinates(1,1) ) == cell_val  && board.getCellValue(new Coordinates(2,1) ) == cell_val) 
	    	   ||  (board.getCellValue(new Coordinates(0,2) ) == cell_val && board.getCellValue(new Coordinates(1,2) ) == cell_val  && board.getCellValue(new Coordinates(2,2) ) == cell_val) 
	    	   ||  (board.getCellValue(new Coordinates(0,0) ) == cell_val && board.getCellValue(new Coordinates(1,1) ) == cell_val  && board.getCellValue(new Coordinates(2,2) ) == cell_val)
	    	   ||  (board.getCellValue(new Coordinates(2,0) ) == cell_val && board.getCellValue(new Coordinates(1,1) ) == cell_val  && board.getCellValue(new Coordinates(0,2) ) == cell_val);
		
	}
	
	@Override
	public void gameReset() {
		board = new Board();
		this.playerToMove = true; // O always plays first
	}
	
	
	//make public if you want to unit test || TODO for unit testing
	public int bestB(boolean p, Board b) {  //p is player to move !!! b is the current board.
		
		int i = b.isBoardFinal(b);
		Coordinates[] nextPotentialMoves = null;
		int saveMaxb = -9999;
		
		//System.out.println(" bestB :  IN | DEPTH: " + rec_depth);

		if (i == 1 || i == 2 || i == 0) {
			//board is final
			
			//check for tie
			if (i == 0) {
				//System.out.println(" bestB : OUT | FINAL POSITION | value = 0");
				return 0;
			}
			
			//check for X
			if (i == 1 && p) {
				//System.out.println(" bestB : OUT | FINAL POSITION | value = -1");
				return -1;
			}
			if (i == 1 && !p) {
				//System.out.println(" bestB : OUT | FINAL POSITION | value = 1");
				return 1;
			}
			
			//check for O
			if (i == 2 && p) {
				//System.out.println(" bestB : OUT | FINAL POSITION | value = 1");
				return 1;
			}
			if (i == 2 && !p) {
				//System.out.println(" bestB : OUT | FINAL POSITION | value = -1");
				return -1;
			}

		}
		
		//rec_depth++;
		//System.out.println(" bestB :  IN | DEPTH: " + rec_depth);

		//board is not final , min - max
		if (i == 999) {
			nextPotentialMoves = b.findFreeCells(b);
			
			int idx = 0;
			while (nextPotentialMoves[idx] != null) {
				Coordinates c = nextPotentialMoves[idx];
				
				Board b_next = new Board(b);
				b_next.setCellValue(c, (p)? 2 : 1);	//reminder: (cell value) 1 -> X & 2 -> O
				
				int bb = -1 * this.bestB(!p,b_next);
				
				if (bb == 1)  {
					saveMaxb = 1;
					break;  //winning move found, no need to evaluate next potential moves
				}
				
				if (bb > saveMaxb) {
					saveMaxb = bb;
				}
				//to avoid stack overflow in best move
				if(idx < 8) {
					idx++;
				} else {
					break;
				}
				
			}
			
			//System.out.println(" bestB : OUT | DEPTH: " + rec_depth + " | bestB = " + saveMaxb);
			//rec_depth--;
			//bb contains best(b) value
			return saveMaxb;
		}
		
		return TttEngine.BESTB_ERRORCODE; //error bast value
	}
	
	public void setPlayerToMove(boolean ptm) {
		this.playerToMove = ptm;
	}
	
	
	public void setBoard(Board b) {
		this.board = b;
	}
	
	
	
	
	
	
	
	//-----------------------------------
	//Board Inner Class
	//-----------------------------------
	
	//for unit testing , make public  || TODO for unit testing
	public class Board {
		
		public static final int tttDimension = 3;
		
		
		//0 value ... empty cell
		//1 value ... X cell
		//2 value ... O cell
		private int[][] tttBoard = new int[tttDimension][tttDimension];
		
		private int number_of_free_cells;
		
		//creates empty board
		public Board() {					
			initPosition();
			number_of_free_cells = 9;
			
		}
		
		//copies b board
		public Board(Board b) {

			for (int i = 0; i < tttDimension; i++ ) {
				for (int j = 0; j < tttDimension; j++) {
					this.tttBoard[i][j] = b.tttBoard[i][j];
				}
			}
			
			this.number_of_free_cells = b.number_of_free_cells;
			
		}
		

		public void initPosition() {			//board initialization : 0 -> empty || 1 -> X || 2 -> O
			for (int i = 0; i < tttDimension; i++ ) {
				for (int j = 0; j < tttDimension; j++) {
					this.tttBoard[i][j] = 0;
				}
			}
			
			number_of_free_cells = 9;
		}
		
		
		public void setCellValue(Coordinates c, int val) {
			
			this.tttBoard[c.x][c.y] = val;
			
			this.number_of_free_cells--;
		}
		
		public int getCellValue(Coordinates c) {
			
			return this.tttBoard[c.x][c.y];
						
		}
		
		public int getCellValue(int x, int y) {
			
			return this.tttBoard[x][y];
						
		}
		
		@SuppressWarnings("unused")
		public void setBoard(int cel00, int cel01, int cel02,   //used mostly for testing purposes
							 int cel10, int cel11, int cel12,
							 int cel20, int cel21, int cel22,
							 int number_of_free_cells) {
			
			this.setCellValue(new Coordinates(0,0), cel00);
			this.setCellValue(new Coordinates(0,1), cel01);
			this.setCellValue(new Coordinates(0,2), cel02);
			this.setCellValue(new Coordinates(1,0), cel10);
			this.setCellValue(new Coordinates(1,1), cel11);
			this.setCellValue(new Coordinates(1,2), cel12);
			this.setCellValue(new Coordinates(2,0), cel20);
			this.setCellValue(new Coordinates(2,1), cel21);
			this.setCellValue(new Coordinates(2,2), cel22);
			
			this.number_of_free_cells = number_of_free_cells;
			
			
			
			
			
		}
		
		private Coordinates[] findFreeCells(Board b) {
			
			Coordinates[] cArray = new Coordinates[9];
			
			int h = 0;
			
			
			for (int i = 0; i<3; i++) {
				for (int j = 0; j<3; j++) {
					if (b.getCellValue(i,j) == 0) {
						//System.out.println("findFreeCells : FREE CELL FOUND " + " h = " + h); //DEBUG PRINTS FOR UNIT TESTING
						cArray[h++] = new Coordinates(i,j);
					}
				}
			}
			return cArray;
		}
		
		
		//returns 999 if board is NOT final
		//returns 1 if player X wins
		//returns 2 if player O wins
		//returns 0 if tie
		private int isBoardFinal(Board b) {
			
			boolean final_1,final_2;

			
			final_1 = (b.getCellValue(0,0) == 1 && b.getCellValue(0,1) == 1  && b.getCellValue(0,2) == 1) 
				  ||  (b.getCellValue(1,0) == 1 && b.getCellValue(1,1) == 1  && b.getCellValue(1,2) == 1) 
			      ||  (b.getCellValue(2,0) == 1 && b.getCellValue(2,1) == 1  && b.getCellValue(2,2) == 1) 
			      ||  (b.getCellValue(0,0) == 1 && b.getCellValue(1,0) == 1  && b.getCellValue(2,0) == 1) 
			      ||  (b.getCellValue(0,1) == 1 && b.getCellValue(1,1) == 1  && b.getCellValue(2,1) == 1) 
			      ||  (b.getCellValue(0,2) == 1 && b.getCellValue(1,2) == 1  && b.getCellValue(2,2) == 1) 
			      ||  (b.getCellValue(0,0) == 1 && b.getCellValue(1,1) == 1  && b.getCellValue(2,2) == 1)
			      ||  (b.getCellValue(2,0) == 1 && b.getCellValue(1,1) == 1  && b.getCellValue(0,2) == 1);
		
			final_2 = (b.getCellValue(0,0) == 2 && b.getCellValue(0,1) == 2  && b.getCellValue(0,2) == 2) 
				  ||  (b.getCellValue(1,0) == 2 && b.getCellValue(1,1) == 2  && b.getCellValue(1,2) == 2) 
				  ||  (b.getCellValue(2,0) == 2 && b.getCellValue(2,1) == 2  && b.getCellValue(2,2) == 2) 
				  ||  (b.getCellValue(0,0) == 2 && b.getCellValue(1,0) == 2  && b.getCellValue(2,0) == 2) 
				  ||  (b.getCellValue(0,1) == 2 && b.getCellValue(1,1) == 2  && b.getCellValue(2,1) == 2) 
				  ||  (b.getCellValue(0,2) == 2 && b.getCellValue(1,2) == 2  && b.getCellValue(2,2) == 2) 
				  ||  (b.getCellValue(0,0) == 2 && b.getCellValue(1,1) == 2  && b.getCellValue(2,2) == 2)
				  ||  (b.getCellValue(2,0) == 2 && b.getCellValue(1,1) == 2  && b.getCellValue(0,2) == 2);
			
			if (final_1) {
				return 1;
			} else {
				if (final_2) {
					return 2;
				} else {
					if (this.number_of_free_cells == 0) {
						return 0;
					} else {
						return 999;
					}
				}
			}
		}
		
		
	}//Board

	
	
	
}//TttEngine

