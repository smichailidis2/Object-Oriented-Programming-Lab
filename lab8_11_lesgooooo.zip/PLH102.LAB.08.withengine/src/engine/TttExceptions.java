package engine;

public class TttExceptions extends Exception{
	
	private int errorCode;
	private String errorDescription;
	private boolean winner; //true -> O || false -> X
	
	public final static int    WINNING_POSITION = 100;
	public final static String WINNING_POSITION_DESCRIPTION = "Wining condition reached";
	
	public final static int DRAW_POSITION = 101;
	public final static String DRAW_POSIITON_DESCRIPTION = "Draw condition reached";
	
	public TttExceptions(int errcode, String errDecription) {
		super("TttException");
		this.errorCode = errcode;
		this.errorDescription = errDecription;
	}

	public TttExceptions(int errcode, String errDecription, boolean winner) {
		super("TttException");
		this.errorCode = errcode;
		this.errorDescription = errDecription;
		this.winner = winner;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public boolean isWinner() {
		return winner;
	}

	public void setWinner(boolean winner) {
		this.winner = winner;
	}
	
}
