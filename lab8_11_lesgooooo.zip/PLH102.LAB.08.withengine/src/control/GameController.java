package control;

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

import engine.Coordinates;
import engine.TttEngine;
import engine.TttEngineInterface;
import engine.TttExceptions;
import model.AI;
import model.GameModel;
import model.Person;
import model.Player;
import model.PlayersCatalogue;
import view.MainAreaPanel;
import view.MainWindow;

public class GameController extends WindowAdapter {
	MainWindow view;
	GameModel model;
	public TttEngineInterface engine;
	
	//flags
	private int game_mode = 0;

	public static final int GAME_MODE_BOT_BOT = -5;
	public static final int GAME_MODE_HUMAN_BOT = -4;
	public static final int GAME_MODE_BOT_HUMAN = -3;
	public static final int GAME_MODE_HUMAN_HUMAN = -2;
	
	
	
	public GameController(TttEngineInterface e) {		
		this.engine = e;
	}
	
	@Override
	public void windowClosing(WindowEvent event) {
		quit();
	}
	
	
	public void start() {
		this.view= new MainWindow(this);
		this.model = new GameModel(this);
		this.view.addWindowListener(this);
		this.view.setVisible(true);
		
		//sets initial state
		GameStates.resetState();
	}
	
	public void quit() {		
		System.out.println("bye bye...");		
		System.exit(0);
	}
	
	
	public void selectPlayer(String p, int pos) {
		this.model.selectPlayer(p, pos);
		
		this.model.selectPlayerFormList(p, pos);
		
		System.out.println("Player " + pos + " set to " + p);
		
		//this.view.getTopPanel().getStartBtn().setEnabled(model.ready());	
		
		//sets state to 1 or 2
		if (pos == 0) {
			GameStates.changeState(GameStates.EVENT_SEL_PLAYER_1);
		} else {
			if (pos == 1) {
				GameStates.changeState(GameStates.EVENT_SEL_PLAYER_2);
			}
		}
		
		this.view.getTopPanel().getStartBtn().setEnabled(GameStates.first_player_selected && GameStates.second_player_selected);
		
		
	}
	
	public void startGame() {
		//sets state to 3
		GameStates.changeState(GameStates.EVENT_START_GAME);
		
		
		this.model.setGameBoard(new String[3][3]);
		this.model.initBoard();
		this.view.getTopPanel().getStartBtn().setEnabled(false);
		this.view.getMainPanel().showCard(MainAreaPanel.BOARD);
		this.view.getLeftPanel().getSelectPlayerBtn().setEnabled(model.NoPlay());
		this.view.getRightPanel().getSelectPlayerBtn().setEnabled(model.NoPlay());
		
		Player player1 = this.model.getGamePlayersObj()[0];
		Player player2 = this.model.getGamePlayersObj()[1];
		System.out.println("player 1 = " + player1.toString()); //DEBUG PRINT
		System.out.println("player 2 = " + player2.toString()); //DEBUG PRINT
		
		System.out.println("player 1 is : " + ((player1 instanceof AI) ? "BOT" : "HUMAN") );
		System.out.println("player 2 is : " + ((player2 instanceof AI) ? "BOT" : "HUMAN") );
		
		
		this.engine.gameReset();
		
		//set game mode
		if (  (player1 instanceof AI) && (player2 instanceof AI)  ) {
			this.game_mode = GAME_MODE_BOT_BOT;
		} else {
			if (  (player1 instanceof Person) && (player2 instanceof AI)  ) {
				this.game_mode = GAME_MODE_HUMAN_BOT;
			} else {
				if (  (player1 instanceof AI) && (player2 instanceof Person)  ) {
					this.game_mode = GAME_MODE_BOT_HUMAN;
				} else {
					if (  (player1 instanceof Person) && (player2 instanceof Person)   ) {
						this.game_mode = GAME_MODE_HUMAN_HUMAN;
					}
				}
			}
		}
		
		switch (this.game_mode) {
		
			case GAME_MODE_BOT_BOT:
				
				  Thread thread = new Thread(){
					    public void run(){
					      System.out.println("Thread Running");
					      botbotGame();
					    }
					  };

					  thread.start();
				
				break;
			case GAME_MODE_HUMAN_BOT:
				break;
			
			
		}
		
	}

	
	//
	private void botbotGame() {
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		AI player1 = (AI) this.model.getGamePlayersObj()[0];
		AI player2 = (AI) this.model.getGamePlayersObj()[1];
		
		while (!this.engine.isFinalBoard()) {
			
			//----------------------------------------
			//First BOT move
			//----------------------------------------
			
			System.out.println("PLAYER TO MOVE: " + player1.toString());
			
			//get move from engine
			Coordinates move = player1.makeAImove();
			
			//display the move
			if (this.model.inPlay()) {
				this.model.makeMove(move.getX(), move.getY());
				this.performMove(move.getX(), move.getY());
				
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				this.view.getMainPanel().repaint();			
			}
			
			//check if game is over
			if (GameStates.state == GameStates.STATE_GAME_FINISH ) {
				break;
			}
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			//----------------------------------------
			//Second BOT move
			//----------------------------------------
			
			System.out.println("PLAYER TO MOVE: " + player2.toString());
			
			//get move from engine
			Coordinates move2 = player2.makeAImove();
			
			//display the move
			if (this.model.inPlay()) {
				this.model.makeMove(move2.getX(), move2.getY());
				this.performMove(move2.getX(), move2.getY());
				
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				this.view.getMainPanel().repaint();				
			}
			
			//check if game is over
			if (GameStates.state == GameStates.STATE_GAME_FINISH ) {
				break;
			}
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}

	public GameModel getModel() {
		return model;
	}
	
	public MainWindow getView() {
		return view;
	}
	
	
	//communicates with the engine to register a  new move,
	//also checks if game is over 
	public void performMove(int row, int col) {
		
		int err = 0;
		
		try {
			this.engine.makeMove(new Coordinates(row,col));
		} catch (TttExceptions e1) {
			//e1.printStackTrace();
			err = e1.getErrorCode();
			
			if (err == TttExceptions.WINNING_POSITION || err == TttExceptions.DRAW_POSITION) {
				GameStates.changeState(GameStates.EVENT_END_GAME);
				System.out.println("GAME OVER!!!");
				
				if(err ==TttExceptions.WINNING_POSITION) {
					String winner = (e1.isWinner()) ? "O" : "X";
					System.out.println("WINNER IS  " + winner + "  !");
				}
				
				if(err == TttExceptions.DRAW_POSITION) {
					System.out.println("TIE GAME!!!");
				}
				
				this.view.getTopPanel().getDoneBtn().setEnabled(true);
			}
		}
	}
	
	//JButton doneButton pressed
	public void gameDone() {
		GameStates.changeState(GameStates.EVENT_RESET_GAME);
		this.view.getTopPanel().getDoneBtn().setEnabled(false);
		this.view.getLeftPanel().getSelectPlayerBtn().setEnabled(true);
		this.view.getRightPanel().getSelectPlayerBtn().setEnabled(true);
	}
	
	//add player button pressed
	public void addPlayer() {
        String playerName = JOptionPane.showInputDialog(
                null,
                "Please enter the new player's name"
                );
        //System.out.println(playerName);
        this.model.getPlayerCatalogue().addPlayerToCatalog(playerName);

    }
	
	public int getGame_mode() {
		return game_mode;
	}

	public void setGame_mode(int game_mode) {
		this.game_mode = game_mode;
	}
	
			
	
}
