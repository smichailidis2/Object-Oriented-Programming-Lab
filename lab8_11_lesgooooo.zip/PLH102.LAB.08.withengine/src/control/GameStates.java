package control;

public class GameStates {
	
	public static boolean first_player_selected = false;
	public static boolean second_player_selected = false;
	
	public final static int STATE_INITIAL = 0;
	public final static int STATE_SELECT_PLAYER_1 = 1;
	public final static int STATE_SELECT_PLAYER_2 = 2;
	public final static int STATE_GAME_START = 3;
	public final static int STATE_GAME_FINISH = 4;
	
	public final static int EVENT_SEL_PLAYER_1 = 100;
	public final static int EVENT_SEL_PLAYER_2 = 200;
	public final static int EVENT_START_GAME = 300;
	public final static int EVENT_END_GAME = 999;
	public final static int EVENT_RESET_GAME = 1000; 

	public final static int ERROR_STATE = -1;
	
	public static int state;
	 
	public GameStates() {
		state = STATE_INITIAL;
		first_player_selected = false;
		second_player_selected = false;
	}
	
	public static void changeState(int event) {
		
		switch (state) {
		
		case STATE_INITIAL:
			
			switch (event) {
			
			case EVENT_SEL_PLAYER_1:
				state = STATE_SELECT_PLAYER_1;
				first_player_selected = true;
				break;
			case EVENT_SEL_PLAYER_2:
				state = STATE_SELECT_PLAYER_2;
				second_player_selected = true;
				break;
			default:
				state = ERROR_STATE;
			
			}//switch (event)
			break;
			
		case STATE_SELECT_PLAYER_1:
			
			switch (event) {
			
			case EVENT_SEL_PLAYER_1: //if event is to select player 1 again , do nothing;
				break;
			case EVENT_SEL_PLAYER_2:
				state = STATE_SELECT_PLAYER_2;
				second_player_selected = true;
				break;
			case EVENT_START_GAME:
				if (first_player_selected && second_player_selected) { //game starts only if both players selected
					state = STATE_GAME_START;
				} else {
					state = ERROR_STATE;
				}
				break;
			default:
				state = ERROR_STATE;
			
			}//switch (event)			
			break;
			
		case STATE_SELECT_PLAYER_2:
			
			switch (event) {
			
			case EVENT_SEL_PLAYER_2: //if event is to select player 2 again , do nothing;
				break;
			case EVENT_SEL_PLAYER_1:
				state = STATE_SELECT_PLAYER_1;
				first_player_selected = true;
				break;
			case EVENT_START_GAME:
				if (first_player_selected && second_player_selected) { //game starts only if both players selected
					state = STATE_GAME_START;
				} else {
					state = ERROR_STATE;
				}
				break;
			default:
				state = ERROR_STATE;
			
			}//switch (event)				
			break;
			
		case STATE_GAME_START:
			if (event == EVENT_END_GAME) {
				state = STATE_GAME_FINISH;
			} else {
				state = ERROR_STATE;
			}
			break;
			
		case STATE_GAME_FINISH:
			if(event == EVENT_RESET_GAME) {
				resetState();
			} else {
				state = ERROR_STATE;
			}
			break;
			
		}//switch (state)
		
		
	}
	
	public static void resetState() {
		state = STATE_INITIAL;
		first_player_selected = false;
		second_player_selected = false;
	}

	/*public int getState() {
		return state;
	}
	
	//use only for unit testing
	public void setState(int state) {
		state = state;
	}
	*/
	
}
